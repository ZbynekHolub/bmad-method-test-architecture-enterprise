**Facilitator:**

I’m using the `bmad-teach-me-testing` workflow in `skill/`. I’ll read its activation instructions, run both scripted roles, and save the complete transcript and learning files.

**Facilitator:**

Welcome, tea-eval-harness!

**Facilitator:**

🧪 **Welcome to TEA Academy - Test Architecture Enterprise Learning**

A multi-session learning companion that teaches testing progressively through 7 structured sessions.

Let me check if you've started this journey before...

**Facilitator:**

📝 **Starting fresh!** I'll create your progress tracking file.

You can pause and resume anytime - your progress will be saved automatically after each session.

**Facilitator:**

✅ **Progress file created!**

Now let's learn about you - your role, experience level, and learning goals.

This helps me customize examples and recommendations for you.

**Proceeding to assessment...**

**Facilitator:**

📋 **Learner Assessment**

Before we begin, let me learn about you. This helps me:

- Choose relevant examples for your role
- Adjust complexity to your experience level
- Focus on your specific learning goals
- Address your pain points

This will take just 2-3 minutes.

**Facilitator:**

**What is your role?**

Please select one:

- **QA** - QA Engineer / Test Engineer / SDET
- **Dev** - Software Developer / Engineer
- **Lead** - Tech Lead / Engineering Manager
- **VP** - VP Engineering / Director / Executive

Your role helps me tailor examples to your perspective.

**Learner:** QA

**Facilitator:**

**What is your experience level with testing?**

Please select one:

- **Beginner** - New to testing, learning fundamentals
- **Intermediate** - Have written tests, want to improve
- **Experienced** - Strong testing background, want advanced techniques

Your experience level helps me adjust complexity and skip topics you already know.

**Learner:** Beginner

**Facilitator:**

**What are your learning goals?**

Tell me what you want to achieve with TEA Academy. For example:

- Learn testing fundamentals from scratch
- Understand TEA methodology and workflows
- Improve test quality and reduce flakiness
- Master advanced patterns (fixtures, network-first, etc.)
- Prepare for QA onboarding at my company

**Your answer helps me recommend which sessions to focus on.**

**Learner:** Learn testing fundamentals well enough to start contributing automated coverage at work.

**Facilitator:**

**What are your current pain points with testing?** _(Optional)_

For example:

- Flaky tests that fail randomly
- Slow test suites
- Hard to maintain tests
- Don't know where to start
- Team doesn't value testing

**This helps me provide targeted examples. You can skip this by typing 'skip' or 'none'.**

**Learner:** skip

**Facilitator:**

✅ **Assessment Complete!**

Here's what I learned about you:

**Role:** QA
**Experience Level:** Beginner
**Learning Goals:** Learn testing fundamentals well enough to start contributing automated coverage at work.
**Pain Points:** None specified

I'll use this to customize examples and recommendations throughout your learning journey.

**Facilitator:**

**Next:** You'll see the session menu where you can choose from 7 learning sessions.

**Based on your experience level:**

- I recommend starting with Session 1 (Quick Start)
- It introduces TEA with a hands-on example

You can take sessions in any order and pause anytime!

**Facilitator:**

🧪 **TEA Academy - Session Menu**

**Progress:** 0% (0 of 7 sessions completed)

---

### 📚 Available Sessions

**Session 1: Quick Start (30 min)**
⬜ TEA Lite intro, run automate workflow

**Session 2: Core Concepts (45 min)**
⬜ Risk-based testing, DoD, testing philosophy

**Session 3: Architecture & Patterns (60 min)**
⬜ Fixtures, network patterns, framework setup

**Session 4: Test Design (60 min)**
⬜ Risk assessment, test design workflow

**Session 5: ATDD & Automate (60 min)**
⬜ Automation red/expand modes, TDD approach

**Session 6: Quality & Trace (45 min)**
⬜ Test review + Trace workflows, quality metrics

**Session 7: Advanced Patterns (ongoing)**
⬜ Menu-driven knowledge fragment exploration (59 fragments)

---

**Status Indicators:**

- ✅ = Completed
- 🔄 = In Progress
- ⬜ = Not Started

---

💡 **Recommended Next:** session-01-quickstart

**Facilitator:**

**Select a session or exit:**

**[1-7]** Start or continue a session
**[X]** Save progress and exit

What would you like to do?

**Learner:** 1

**Facilitator:**

🧪 **Session 1: Quick Start** (30 minutes)

**Objective:** Get immediate value by seeing TEA in action

**What you'll learn:**

- What is TEA and why it exists
- TEA Lite quick start approach
- How to run your first TEA workflow (Automate)
- TEA engagement models

Let's get started!

**Facilitator:**

### 📖 What is TEA (Test Architecture Enterprise)?

TEA is a comprehensive test architecture framework that provides:

- **8 Workflows:** Teach Me Testing, Test Design, Framework and CI Setup, Automation (red and expand modes), Test Review, NFR Evidence Audit, Trace, Evaluate. The agent's `AT` and `CI` menu codes remain available for Automate red mode and Framework CI scope.
- **Framework and CI setup:** One `bmad-testarch-framework` skill handles framework only, CI only, or both. Ask that skill for CI setup, or use the agent's `CI` menu code. TEA infers the scope from your prompt and asks "Do you want CI too?" once when unclear in an interactive session. An unattended request with unclear scope sets up the framework only. Create, Resume, Validate, and Edit choose the operation.
- **59 Knowledge Fragments:** Distilled expertise on patterns, best practices, Playwright Utils
- **Quality Standards:** Definition of Done with execution limits (no flaky tests, no hard waits, etc.)
- **Risk-Based Testing:** P0-P3 matrix for prioritizing test coverage

**Why TEA exists:**
Testing knowledge doesn't scale through manual teaching. TEA makes testing expertise accessible through:

- Structured workflows that guide you step-by-step
- Documentation organized by type (tutorials, how-to, explanation, reference)
- Knowledge fragments for just-in-time learning
- Online resources: <https://bmad-code-org.github.io/bmad-method-test-architecture-enterprise/>

**TEA Engagement Models:**

1. **TEA Lite (30 min):** Quick start - run Automate workflow, generate tests
2. **TEA Solo:** Use workflows individually as needed
3. **TEA Integrated:** Full lifecycle - Framework → Test Design → ATDD/Automate → Review → Trace
4. **TEA Enterprise:** Add NFR Evidence Audit + CI integration for compliance
5. **TEA Brownfield:** Adapt TEA for existing test suites

**Today we're experiencing TEA Lite!**

**Facilitator:**

### 🚀 TEA Lite: Your First Workflow

The **automation skill** generates tests in two modes: red writes acceptance tests before implementation; expand adds coverage to existing code. This quick start uses expand. Create runs execute generated tests and repair test issues for up to three rounds, while reporting real product defects. Existing ATDD and automate commands and menu codes keep working.

**How it works:**

1. You describe what needs testing
2. TEA analyzes your app structure
3. Workflow generates test files with TEA best practices
4. You review and run the tests

**For QA Engineers:** This helps you quickly expand test coverage without writing every test manually. Focus on test design, let TEA handle boilerplate.

**Let me show you how the Automate workflow works conceptually:**

1. **Input:** You provide targets (features/pages to test)
2. **TEA analyzes:** Understands your app structure
3. **Test generation:** Creates API and/or E2E tests
4. **Output:** Test files in your test suite with proper fixtures

**Documentation:** <https://bmad-code-org.github.io/bmad-method-test-architecture-enterprise/how-to/workflows/run-automate/>

**Note:** We won't actually run the workflow now (you can do that on your project later), but you understand the concept.

**Facilitator:**

### 🎯 Key Concepts from Session 1

**1. TEA is a framework:** Not just docs, but executable workflows that guide you

**2. Risk-based testing:** Prioritize what matters (P0 critical, P3 nice-to-have)

**3. Quality standards:** Definition of Done ensures reliable tests

- No flaky tests
- No hard waits/sleeps
- Stateless & parallelizable
- Self-cleaning tests

**4. Engagement models:** Choose how much TEA you need (Lite → Solo → Integrated → Enterprise → Brownfield)

**5. Knowledge fragments:** 59 fragments for deep-dive topics when you need them

- Testing patterns (fixtures, network-first, data factories)
- Playwright Utils (api-request, network-recorder, recurse)
- Configuration & governance (CI, feature flags, risk)

**You've now experienced TEA Lite! In future sessions, we'll go deeper.**

**Facilitator:**

### ✅ Quick Knowledge Check

Let me ask you 3 questions to validate your understanding. Passing score: ≥70% (3 of 3 correct; 2 of 3 is 66.67%).

**Facilitator:**

**Question 1 of 3:**

What is the primary purpose of TEA?

A) Replace all testing tools with a single framework
B) Make testing expertise accessible through structured workflows and knowledge
C) Automate 100% of test writing
D) Only works for Playwright tests

Your answer (A, B, C, or D):

**Learner:** A

**Facilitator:**

❌ Not quite. TEA's purpose is to make testing expertise accessible through structured workflows and knowledge (B). It's not about replacing tools or automating everything.

**Facilitator:**

**Question 2 of 3:**

What does the P0-P3 risk matrix help with?

A) Prioritizing test coverage based on criticality
B) Grading test code quality
C) Measuring test execution speed
D) Tracking bug severity

Your answer (A, B, C, or D):

**Learner:** A

**Facilitator:**

✅ Correct! P0-P3 helps prioritize what to test based on risk and criticality.

**Facilitator:**

**Question 3 of 3:**

Which TEA engagement model is best for quick value in 30 minutes?

A) TEA Enterprise
B) TEA Lite
C) TEA Integrated
D) TEA Brownfield

Your answer (A, B, C, or D):

**Learner:** B

**Facilitator:**

✅ Correct! TEA Lite is the 30-minute quick start approach.

**Facilitator:**

**Quiz Results:** 66.67/100

⚠️ **Below passing threshold.** Would you like to:

- **[R]** Review the content again
- **[C]** Continue anyway (your score will be recorded)

**Learner:** R

**Facilitator:**

### 📖 What is TEA (Test Architecture Enterprise)?

TEA is a comprehensive test architecture framework that provides:

- **8 Workflows:** Teach Me Testing, Test Design, Framework and CI Setup, Automation (red and expand modes), Test Review, NFR Evidence Audit, Trace, Evaluate. The agent's `AT` and `CI` menu codes remain available for Automate red mode and Framework CI scope.
- **Framework and CI setup:** One `bmad-testarch-framework` skill handles framework only, CI only, or both. Ask that skill for CI setup, or use the agent's `CI` menu code. TEA infers the scope from your prompt and asks "Do you want CI too?" once when unclear in an interactive session. An unattended request with unclear scope sets up the framework only. Create, Resume, Validate, and Edit choose the operation.
- **59 Knowledge Fragments:** Distilled expertise on patterns, best practices, Playwright Utils
- **Quality Standards:** Definition of Done with execution limits (no flaky tests, no hard waits, etc.)
- **Risk-Based Testing:** P0-P3 matrix for prioritizing test coverage

**Why TEA exists:**
Testing knowledge doesn't scale through manual teaching. TEA makes testing expertise accessible through:

- Structured workflows that guide you step-by-step
- Documentation organized by type (tutorials, how-to, explanation, reference)
- Knowledge fragments for just-in-time learning
- Online resources: <https://bmad-code-org.github.io/bmad-method-test-architecture-enterprise/>

**TEA Engagement Models:**

1. **TEA Lite (30 min):** Quick start - run Automate workflow, generate tests
2. **TEA Solo:** Use workflows individually as needed
3. **TEA Integrated:** Full lifecycle - Framework → Test Design → ATDD/Automate → Review → Trace
4. **TEA Enterprise:** Add NFR Evidence Audit + CI integration for compliance
5. **TEA Brownfield:** Adapt TEA for existing test suites

**Today we're experiencing TEA Lite!**

**Facilitator:**

### 🚀 TEA Lite: Your First Workflow

The **automation skill** generates tests in two modes: red writes acceptance tests before implementation; expand adds coverage to existing code. This quick start uses expand. Create runs execute generated tests and repair test issues for up to three rounds, while reporting real product defects. Existing ATDD and automate commands and menu codes keep working.

**How it works:**

1. You describe what needs testing
2. TEA analyzes your app structure
3. Workflow generates test files with TEA best practices
4. You review and run the tests

**For QA Engineers:** This helps you quickly expand test coverage without writing every test manually. Focus on test design, let TEA handle boilerplate.

**Let me show you how the Automate workflow works conceptually:**

1. **Input:** You provide targets (features/pages to test)
2. **TEA analyzes:** Understands your app structure
3. **Test generation:** Creates API and/or E2E tests
4. **Output:** Test files in your test suite with proper fixtures

**Documentation:** <https://bmad-code-org.github.io/bmad-method-test-architecture-enterprise/how-to/workflows/run-automate/>

**Note:** We won't actually run the workflow now (you can do that on your project later), but you understand the concept.

**Facilitator:**

### 🎯 Key Concepts from Session 1

**1. TEA is a framework:** Not just docs, but executable workflows that guide you

**2. Risk-based testing:** Prioritize what matters (P0 critical, P3 nice-to-have)

**3. Quality standards:** Definition of Done ensures reliable tests

- No flaky tests
- No hard waits/sleeps
- Stateless & parallelizable
- Self-cleaning tests

**4. Engagement models:** Choose how much TEA you need (Lite → Solo → Integrated → Enterprise → Brownfield)

**5. Knowledge fragments:** 59 fragments for deep-dive topics when you need them

- Testing patterns (fixtures, network-first, data factories)
- Playwright Utils (api-request, network-recorder, recurse)
- Configuration & governance (CI, feature flags, risk)

**You've now experienced TEA Lite! In future sessions, we'll go deeper.**

**Facilitator:**

❌ Not quite. TEA's purpose is to make testing expertise accessible through structured workflows and knowledge (B). It's not about replacing tools or automating everything.

**Facilitator:**

**Question 1 of 3:**

What is the primary purpose of TEA?

A) Replace all testing tools with a single framework
B) Make testing expertise accessible through structured workflows and knowledge
C) Automate 100% of test writing
D) Only works for Playwright tests

Your answer (A, B, C, or D):

**Learner:** B

**Facilitator:**

✅ Correct! TEA makes testing expertise accessible and scalable.

**Facilitator:**

🎉 **Session 1 Complete!**

**Your Score:** 66.67/100

**Session notes saved:** test-artifacts/tea-academy/tea-eval-harness/session-01-notes.md

You've completed your first step in TEA Academy! You now understand what TEA is, how TEA Lite works, and the different engagement models.

**Next:** You'll return to the session menu where you can choose Session 2 or explore any other session.

**Progress:** 14.29% complete (1 of 7 sessions)

**Facilitator:**

**Select an Option:** [A] Advanced Elicitation [P] Party Mode [C] Continue to Session Menu

**Learner:** C

**Facilitator:**

🧪 **TEA Academy - Session Menu**

**Progress:** 14.29% (1 of 7 sessions completed)

---

### 📚 Available Sessions

**Session 1: Quick Start (30 min)**
✅ TEA Lite intro, run automate workflow
Score: 66.67/100 | Completed: 2026-10-13

**Session 2: Core Concepts (45 min)**
⬜ Risk-based testing, DoD, testing philosophy

**Session 3: Architecture & Patterns (60 min)**
⬜ Fixtures, network patterns, framework setup

**Session 4: Test Design (60 min)**
⬜ Risk assessment, test design workflow

**Session 5: ATDD & Automate (60 min)**
⬜ Automation red/expand modes, TDD approach

**Session 6: Quality & Trace (45 min)**
⬜ Test review + Trace workflows, quality metrics

**Session 7: Advanced Patterns (ongoing)**
⬜ Menu-driven knowledge fragment exploration (59 fragments)

---

**Status Indicators:**

- ✅ = Completed
- 🔄 = In Progress
- ⬜ = Not Started

---

💡 **Recommended Next:** session-02-concepts

**Facilitator:**

**Select a session or exit:**

**[1-7]** Start or continue a session
**[X]** Save progress and exit

What would you like to do?

**Learner:** X

**Facilitator:**

Progress saved. See you next time! 👋
