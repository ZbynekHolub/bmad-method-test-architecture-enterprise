---
runScope: 'system'
runKey: 'system'
workflowStatus: 'completed'
stepsCompleted: ['step-01-load-context', 'step-02-define-thresholds', 'step-03-gather-evidence', 'step-04-evaluate-and-score', 'step-04e-aggregate-nfr', 'step-05-generate-report']
lastStep: 'step-05-generate-report'
lastSaved: '2026-10-13'
workflowType: 'testarch-nfr-assess'
inputDocuments: ["atlas-notification-relay/_bmad/config.toml", "atlas-notification-relay/docs/tech-spec.md", "bmod-tea/knowledge/tea-index.csv", "bmod-tea/knowledge/adr-quality-readiness-checklist.md", "bmod-tea/knowledge/ci-burn-in.md", "bmod-tea/knowledge/test-quality.md", "bmod-tea/knowledge/playwright-config.md", "bmod-tea/knowledge/error-handling.md", "atlas-notification-relay/config/logging.json", "atlas-notification-relay/evidence/coverage-summary-2026-09-01.json", "atlas-notification-relay/evidence/dependency-scan-2026-09-01.json", "atlas-notification-relay/evidence/duplication-report-2026-09-01.json", "atlas-notification-relay/evidence/load-test-2026-09-02.json", "atlas-notification-relay/evidence/reliability-2026-09.json", "atlas-notification-relay/evidence/security-review-2026-09-01.md"]
---

# NFR Evidence Audit: Atlas Notification Relay

**Date:** 2026-10-13

**Scope:** Whole service (`system`)

**Overall Status:** PASS ✅

**Overall Risk:** LOW

Note: This audit summarizes the supplied implementation evidence. Tests and CI workflows were not run. All evidence citations use paths relative to the supplied project root, `atlas-notification-relay/`. The assessed release bundle covers August and early September 2026. Referenced source and test files inside supplied reviews were not independently supplied or evaluated.

## Executive Summary

**Assessment:** 19 PASS, 0 CONCERNS, 0 FAIL.

**Blockers:** 0.

**High Priority Issues:** 0.

**Evidence Gaps:** 0.

**Recommendation:** Proceed to `/bmad-testarch-trace` Phase 2 for the release gate decision. No NFR waiver or remediation is required by the audited criteria.

## Performance Assessment

**Domain Status:** PASS ✅

**Risk Level:** LOW

### Response time

- **Criterion ID:** `performance-response-time`
- **Source Order:** 1
- **Status:** PASS ✅
- **Threshold:** The enqueue API answers in under 300 ms at p95 under the release load profile.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 168 ms p95 during the release load profile.
- **Evidence:** `evidence/load-test-2026-09-02.json`
- **Supports:** k6 release load profile with 400 virtual users for 30 minutes reports p95 response time 168 ms.
- **Findings:** 168 ms is below the strict 300 ms ceiling. The load profile used 400 virtual users for 30 minutes.

### Throughput

- **Criterion ID:** `performance-throughput`
- **Source Order:** 2
- **Status:** PASS ✅
- **Threshold:** The relay sustains at least 250 requests per second.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 402 requests per second over 30 minutes; 723,600 requests.
- **Evidence:** `evidence/load-test-2026-09-02.json`
- **Supports:** k6 release load profile reports 402 requests per second across 723,600 requests in 30 minutes.
- **Findings:** 402 requests/s meets the minimum of 250 requests/s.

### CPU usage

- **Criterion ID:** `performance-cpu-usage`
- **Source Order:** 3
- **Status:** PASS ✅
- **Threshold:** Peak CPU stays below 70% during the load profile.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 51% peak CPU.
- **Evidence:** `evidence/load-test-2026-09-02.json`
- **Supports:** k6 release load profile reports peak CPU 51%.
- **Findings:** 51% is below the strict 70% ceiling.

### Memory usage

- **Criterion ID:** `performance-memory-usage`
- **Source Order:** 4
- **Status:** PASS ✅
- **Threshold:** Peak heap stays below 75% during the load profile.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 62% peak heap.
- **Evidence:** `evidence/load-test-2026-09-02.json`
- **Supports:** k6 release load profile reports peak heap 62%.
- **Findings:** 62% is below the strict 75% ceiling.

## Security Assessment

**Domain Status:** PASS ✅

**Risk Level:** LOW

### Authentication

- **Criterion ID:** `security-authentication`
- **Source Order:** 5
- **Status:** PASS ✅
- **Threshold:** Every relay API call presents an OAuth 2.1 access token whose lifetime is 15 minutes or less. Refresh tokens rotate on use.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** OAuth 2.1 with PKCE; 900-second (15-minute) access tokens; refresh tokens rotate on every use; expired-token replay covered every route.
- **Evidence:** `evidence/security-review-2026-09-01.md`
- **Supports:** Security review of relay@2.3.0 reports OAuth 2.1 with PKCE, 900-second access tokens, refresh rotation on every use, and expired-token replay against every route.
- **Findings:** The 15-minute lifetime meets the inclusive maximum, and the review verifies refresh-token rotation and route-wide expired-token rejection.

### Authorization

- **Criterion ID:** `security-authorization`
- **Source Order:** 6
- **Status:** PASS ✅
- **Threshold:** Service-scoped RBAC is enforced on every relay endpoint. A token issued for one product service must never read another service's delivery receipts.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** Service-scoped RBAC ahead of every route; all 7 cross-service read attempts returned 403 with audit records.
- **Evidence:** `evidence/security-review-2026-09-01.md`
- **Supports:** Security review reports service-scoped RBAC ahead of every route and 7 of 7 cross-service read attempts refused with 403 and audit records.
- **Findings:** The route-wide guard and 7 of 7 refused cross-service reads support the declared isolation requirement.

### Data protection

- **Criterion ID:** `security-data-protection`
- **Source Order:** 7
- **Status:** PASS ✅
- **Threshold:** Message bodies are encrypted at rest with AES-256 and in transit with TLS 1.3, and are deleted 24 hours after delivery.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** AES-256 at rest; TLS 1.3 ingress and outbound webhooks; hourly deletion; no message body older than 24 hours among 1.2 million delivered messages audited September 1.
- **Evidence:** `evidence/security-review-2026-09-01.md`
- **Supports:** Security review reports AES-256 at rest and TLS 1.3 for ingress and outbound webhooks. An hourly deletion job left no message body older than 24 hours across 1.2 million delivered messages in the September 1 audit.
- **Findings:** The review supports all three declared controls: encryption at rest, transport encryption, and 24-hour deletion.

### Vulnerability management

- **Criterion ID:** `security-vulnerability-management`
- **Source Order:** 8
- **Status:** PASS ✅
- **Threshold:** A release ships with 0 critical and 0 high severity dependency findings.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 0 critical, 0 high, 1 moderate, and 4 low findings for relay@2.3.0.
- **Evidence:** `evidence/dependency-scan-2026-09-01.json`
- **Supports:** npm audit for relay@2.3.0 reports 0 critical and 0 high findings, with 1 moderate and 4 low findings.
- **Findings:** The prohibited critical/high counts are zero. Moderate and low findings are permitted by the declared release threshold.

### Compliance

- **Criterion ID:** `security-compliance`
- **Source Order:** 9
- **Status:** PASS ✅
- **Threshold:** GDPR applies: the relay is a processor for the recipient data Atlas product services send it, and the data-processing record and the 24-hour retention control are the evidence for it.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** Processor record reviewed August 28 and current; 24-hour retention control; subject erasure within one hour; compliance sign-off September 1.
- **Evidence:** `evidence/security-review-2026-09-01.md`
- **Supports:** Security review reports a current processor data-processing record reviewed August 28, the 24-hour retention control, erasure within one hour, and compliance sign-off September 1.
- **Findings:** The supplied review verifies the processor record and required retention control; GDPR is the only declared compliance standard.

## Reliability Assessment

**Domain Status:** PASS ✅

**Risk Level:** LOW

### Availability

- **Criterion ID:** `reliability-availability`
- **Source Order:** 10
- **Status:** PASS ✅
- **Threshold:** Monthly uptime at or above 99.9%.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 99.96% monthly uptime; 17 minutes downtime in August 2026.
- **Evidence:** `evidence/reliability-2026-09.json`
- **Supports:** Platform observability export for August 2026 reports uptime 99.96% and downtime 17 minutes.
- **Findings:** 99.96% meets the inclusive 99.9% minimum for the supplied monthly window.

### Error rate

- **Criterion ID:** `reliability-error-rate`
- **Source Order:** 11
- **Status:** PASS ✅
- **Threshold:** The monthly 5xx rate stays below 0.5% of relay API requests.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 0.07% monthly server-error rate; 43,498 errors / 62,140,000 requests in August 2026.
- **Evidence:** `evidence/reliability-2026-09.json`
- **Supports:** August 2026 export reports 43,498 server errors among 62,140,000 requests, a 0.07% error rate.
- **Findings:** 0.07% is below the strict 0.5% ceiling.

### MTTR

- **Criterion ID:** `reliability-mttr`
- **Source Order:** 12
- **Status:** PASS ✅
- **Threshold:** A relay incident is restored within 15 minutes.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 6 minutes MTTR; the listed incident restored in 6 minutes.
- **Evidence:** `evidence/reliability-2026-09.json`
- **Supports:** August 2026 export reports MTTR 6 minutes; the listed incident restored in 6 minutes.
- **Findings:** The recorded 6-minute restoration meets the 15-minute limit.

### Fault tolerance

- **Criterion ID:** `reliability-fault-tolerance`
- **Source Order:** 13
- **Status:** PASS ✅
- **Threshold:** The delivery worker opens a circuit breaker after five consecutive transport failures, and the region failover drill runs once a quarter.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** Circuit breaker opens after 5 consecutive failures and opened and closed automatically during the August 9 incident. The August 21 region failover drill passed in 22 seconds with no data loss.
- **Evidence:** `evidence/reliability-2026-09.json`
- **Supports:** The breaker opens after 5 consecutive failures and opened and closed automatically during the August 9 incident. The August 21 region failover drill passed in 22 seconds with no data loss.
- **Findings:** The breaker failure count matches five. The passed August drill supplies the quarterly regional recovery observation for the release evidence period.

### CI burn-in

- **Criterion ID:** `reliability-ci-burn-in`
- **Source Order:** 14
- **Status:** PASS ✅
- **Threshold:** 100 consecutive green runs of the relay suite precede a release.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 312 consecutive green runs of the relay suite; last failure May 11, 2026.
- **Evidence:** `evidence/reliability-2026-09.json`
- **Supports:** The relay suite has 312 consecutive green runs; the last failure was May 11, 2026.
- **Findings:** 312 consecutive green runs exceeds the required 100.

## Maintainability Assessment

**Domain Status:** PASS ✅

**Risk Level:** LOW

### Test coverage

- **Criterion ID:** `maintainability-test-coverage`
- **Source Order:** 16
- **Status:** PASS ✅
- **Threshold:** Statement coverage of the relay service stays at or above 80%.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 88.4% aggregate statement coverage for relay@2.3.0.
- **Evidence:** `evidence/coverage-summary-2026-09-01.json`
- **Supports:** c8 reports aggregate statement coverage 88.4% for relay@2.3.0.
- **Findings:** The service-wide 88.4% meets the 80% aggregate threshold.

### Code duplication

- **Criterion ID:** `maintainability-code-duplication`
- **Source Order:** 17
- **Status:** PASS ✅
- **Threshold:** Duplicated blocks stay below 5% of the relay source.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 2.1% duplicated source; 508 / 24,180 lines; 11 clones.
- **Evidence:** `evidence/duplication-report-2026-09-01.json`
- **Supports:** jscpd for relay@2.3.0 reports 2.1% duplication, 508 of 24,180 lines, and 11 clones.
- **Findings:** 2.1% is below the strict 5% ceiling.

### Dependency vulnerabilities

- **Criterion ID:** `maintainability-dependency-vulnerabilities`
- **Source Order:** 18
- **Status:** PASS ✅
- **Threshold:** 0 critical and 0 high severity findings, matching the security requirement above.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** 0 critical, 0 high, 1 moderate, and 4 low findings for relay@2.3.0.
- **Evidence:** `evidence/dependency-scan-2026-09-01.json`
- **Supports:** npm audit for relay@2.3.0 reports 0 critical and 0 high findings, with 1 moderate and 4 low findings.
- **Findings:** The prohibited critical/high counts are zero, matching the security requirement.

### Structured logging

- **Criterion ID:** `maintainability-structured-logging`
- **Source Order:** 19
- **Status:** PASS ✅
- **Threshold:** Every relay log line is JSON and carries `service_id`, `trace_id`, and `transport`.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** JSON schema requires service_id, trace_id, and transport. The supplied configuration documents middleware validation and a sampled-line assertion that fails the build for missing fields.
- **Evidence:** `config/logging.json`
- **Supports:** JSON logging requires service_id, trace_id, and transport; the schema states that middleware validation and a sampled-line assertion fail the build for missing fields.
- **Findings:** The documented schema and automated format assertion provide the accepted logging evidence defined in the workflow checklist.

### Error tracking

- **Criterion ID:** `maintainability-error-tracking`
- **Source Order:** 20
- **Status:** PASS ✅
- **Threshold:** Unhandled rejections and 5xx responses reach the error tracker.
- **Threshold Source:** `docs/tech-spec.md`
- **Actual:** Sentry enabled; captures unhandled_rejection, uncaught_exception, and http_5xx; release tagging enabled.
- **Evidence:** `config/logging.json`
- **Supports:** Sentry is enabled and captures unhandled_rejection, uncaught_exception, and http_5xx, with release tagging.
- **Findings:** The supplied integration configuration enables both required event types.

## Recorded-Only NFR Criteria

These criteria are preserved without automated assessment.

| ID | Category | Label | Declared threshold | Threshold Source | Assessment mode |
| --- | --- | --- | --- | --- | --- |
| `reliability-disaster-recovery` | Disaster Recovery | Disaster recovery | RTO 4 hours, RPO 15 minutes. | `docs/tech-spec.md` | RECORDED ONLY |

## Quick Wins

0 quick wins identified. All declared audit criteria pass.

## Recommended Actions

Immediate remediation, short-term remediation, and long-term remediation: N/A. No declared finding requires an action.

Next workflow: `/bmad-testarch-trace` Phase 2 for the release gate decision.

## Monitoring Hooks

N/A. No additional monitoring action is required by an audited finding.

## Fail-Fast Mechanisms

N/A. No additional fail-fast action is required by an audited finding.

## Evidence Gaps

0 evidence gaps. Every declared audited criterion has a supplied implementation observation.

## Findings Summary

| Audited domain | PASS | CONCERNS | FAIL | Domain status | Risk |
| --- | ---: | ---: | ---: | --- | --- |
| Performance | 4 | 0 | 0 | PASS | LOW |
| Security | 5 | 0 | 0 | PASS | LOW |
| Reliability | 5 | 0 | 0 | PASS | LOW |
| Maintainability | 5 | 0 | 0 | PASS | LOW |
| **Total** | **19** | **0** | **0** | **PASS** | **LOW** |

ADR Quality Readiness Checklist scoring: N/A. Step 02 uses the checklist for elicitation and limits findings to explicitly declared criteria. Its 29 generic checklist criteria were not scored. Generic checklist categories, optional scans, browser reports, and other undeclared dimensions create no findings or evidence gaps.

## Compliance Summary

**GDPR:** PASS. See the audited Security Compliance finding and its supplied security-review citation.

## Cross-Domain Risks

Security vulnerability management and maintainability dependency vulnerabilities share the release scan. Both thresholds pass; 1 moderate and 4 low findings remain allowed by the declared limits.

- **Evidence:** `evidence/dependency-scan-2026-09-01.json`
- **Supports:** npm audit for relay@2.3.0 reports 0 critical and 0 high findings, with 1 moderate and 4 low findings.

## Related Artifacts

Story, PRD, and test-design artifacts: N/A; none were supplied for this scope. Threshold sources are listed beside each declared threshold.

Implementation evidence inventory, relative to `atlas-notification-relay/`:

- `config/logging.json`
- `evidence/coverage-summary-2026-09-01.json`
- `evidence/dependency-scan-2026-09-01.json`
- `evidence/duplication-report-2026-09-01.json`
- `evidence/load-test-2026-09-02.json`
- `evidence/reliability-2026-09.json`
- `evidence/security-review-2026-09-01.md`

## Validation Summary

All 19 criteria appear once, with exact labels and declared source order within their domains. All 19 criterion-bound observations are published with exact canonical ledger paths and supported statements. All citations passed the publication audit. No requirement document appears as implementation evidence. Domain prose and gate values use the same Step 04e rollup. Recorded-only content is confined to its table. Generic checklist items are N/A under the declared-scope rules.

The five mandatory knowledge fragments were loaded. Browser automation was disabled and no browser sessions were opened. Execution used sequential mode with capability probing disabled. Four workers completed in Security, Performance, Reliability, Maintainability order, followed by aggregation and report generation. No service tests or evidence were generated.

## Recommendations Summary

**Release Blocker:** None.

**High Priority:** None.

**Medium Priority:** None.

**Next Steps:** Use `/bmad-testarch-trace` Phase 2 to make the release gate decision.

## Sign-Off

**NFR Evidence Audit:** PASS ✅

**Gate Status:** PASS ✅

Critical issues: 0. High priority issues: 0. Concerns: 0. Evidence gaps: 0. Waivers required: 0.

**Generated:** 2026-10-13

**Workflow:** testarch-nfr v5.0

## Gate YAML Snippet

```yaml
nfr_assessment:
  date: '2026-10-13'
  story_id: null
  run_scope: 'system'
  run_key: 'system'
  feature_name: 'Atlas Notification Relay'
  adr_checklist_score: 'N/A'
  categories: {} # Generic ADR categories were not separately assessed.
  audited_domains:
    security: 'PASS'
    performance: 'PASS'
    reliability: 'PASS'
    maintainability: 'PASS'
  overall_status: 'PASS'
  overall_risk: 'LOW'
  critical_issues: 0
  high_priority_issues: 0
  medium_priority_issues: 0
  concerns: 0
  blockers: false
  quick_wins: 0
  evidence_gaps: 0
  recommendations:
    - 'Run /bmad-testarch-trace Phase 2 for the release gate decision.'
```
