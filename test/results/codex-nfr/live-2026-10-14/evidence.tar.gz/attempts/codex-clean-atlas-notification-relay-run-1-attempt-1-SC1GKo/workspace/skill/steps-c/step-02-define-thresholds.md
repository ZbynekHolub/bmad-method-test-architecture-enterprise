---
name: 'step-02-define-thresholds'
description: 'Identify NFR categories and thresholds'
nextStepFile: '{skill-root}/steps-c/step-03-gather-evidence.md'
outputFile: '{test_artifacts}/nfr/nfr-assessment-{run_key}.md'
---

# Step 2: Define NFR Categories & Thresholds

## STEP GOAL

Establish the NFR categories to assess and the thresholds used for validation.

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- 🚫 Never guess thresholds

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 0. Check for Existing Test-Design NFR Plan

Before deriving thresholds from raw documents, check if a `test-design` output exists with NFR planning:

- Look for `test-design-architecture.md`, `test-design-qa.md`, or a `test-design-epic-{epic_num}.md` covering this run's scope that contains an NFR section. Search `{test_artifacts}/test-design/` first, then the legacy root `{test_artifacts}/` where runs before the `test-design/` folder wrote them.
- If found, **load it as the primary source of NFR categories and thresholds**. Use those values directly; do not re-derive them from scratch.
- Only fall back to raw documents (tech-spec, PRD, story) for categories or thresholds that are still missing or marked **UNKNOWN** in the test-design output.
- If no test-design NFR plan exists, proceed with step 1 using raw documents.

---

## 1. Select Categories

Use the ADR Quality Readiness Checklist (8 categories) only as an elicitation
source for finding explicitly declared requirements:

1. Testability & Automation
2. Test Data Strategy
3. Scalability & Availability
4. Disaster Recovery
5. Security
6. Monitorability/Debuggability/Manageability
7. QoS/QoE
8. Deployability

Add any `custom_nfr_categories` if provided.

The checklist never creates an assessment criterion by itself. Build a canonical
`declared_nfr_criteria` map containing only requirements in the four automated
audit domains: Security, Performance, Reliability, and Maintainability. Put
explicit requirements from every other category in a separate
`recorded_only_nfr_criteria` list. Both collections come only from the supplied
test-design plan, tech spec, PRD, story, or custom configuration.
For each criterion record a stable ID, its source-order position, exact label,
domain, threshold, and canonical threshold-source path. Preserve source order.
Do not add a broad checklist category, evidence gap, or CONCERNS finding when
the supplied requirements do not declare it.

Derive the stable ID mechanically from the domain plus the exact declared label:
lowercase both, replace each run of non-alphanumeric characters with one hyphen,
and trim leading or trailing hyphens. Stop with an explicit ambiguity error if
two criteria produce the same ID. Repeated runs over the same requirements must
produce the same IDs and order.

```json
{
  "{NFR_DOMAIN}": [
    {
      "id": "{STABLE_CRITERION_ID}",
      "order": "{SOURCE_ORDER}",
      "label": "{DECLARED_REQUIREMENT_LABEL}",
      "threshold": "{DECLARED_THRESHOLD_OR_UNKNOWN}",
      "threshold_source": "{PATH_RELATIVE_TO_SUPPLIED_PROJECT_ROOT}"
    }
  ]
}
```

Each recorded-only entry uses the same fields and stable-ID derivation, plus
`assessment_mode: "recorded-only"`. Recorded-only criteria are preserved for
publication with their exact threshold and threshold source. They never enter a
worker payload, finding, domain status, evidence gap, risk rollup, compliance
summary, or gate decision.

**Note:** This workflow's automated evidence audit in Step 4 evaluates exactly four domains: Security, Performance, Reliability, and Maintainability. Security and Performance draw their thresholds from the ADR-8 list above. The Reliability worker consumes availability, error-rate, fault-tolerance, and MTTR thresholds. Disaster Recovery remains a separate ADR-8 category for RTO, RPO, backup, restore, and regional recovery evidence; no automated Step 4 worker evaluates it. Maintainability criteria (test coverage, code duplication, dependency vulnerabilities, structured logging, and error tracking) come directly from `nfr-criteria.md`. Thresholds gathered here for Test Data Strategy, Disaster Recovery, Monitorability, QoS/QoE, and Deployability are recorded for the report and are not evaluated by an automated subagent in this workflow.

---

## 2. Define Thresholds

For each declared criterion, use thresholds from the test-design NFR plan (step 0) where available. For any remaining UNKNOWN or missing thresholds, extract
from:

- tech-spec (primary)
- PRD (secondary)
- story (feature-specific)

If a threshold is still unknown after checking all sources, mark it **UNKNOWN** and plan to report **CONCERNS**.

A requirements document proves only the declared target. Record it as
`threshold_source`; never treat it as implementation evidence or place it in a
finding's `evidence` array.

---

## 3. Confirm NFR Matrix

List each declared NFR criterion with its stable ID, domain, source order,
threshold or UNKNOWN status, threshold source, and assessment mode. The ordered
`declared_nfr_criteria` map is the complete worker assessment scope passed to
Steps 3 through 5. The ordered `recorded_only_nfr_criteria` list is passed to
Step 5 solely for the recorded-only report table.

---

## 4. Save Progress

**Save this step's accumulated work to `{outputFile}`.**

Step 1 created `{outputFile}` for this run's `run_key`, so the file holds only this run's work.

- **If `{outputFile}` does not exist** (first save), create it using the workflow template (if available) with YAML frontmatter:

  ```yaml
  ---
  runScope: '{run_scope}'
  runKey: '{run_key}'
  workflowStatus: 'in-progress'
  stepsCompleted: ['step-02-define-thresholds']
  lastStep: 'step-02-define-thresholds'
  lastSaved: '{date}'
  ---
  ```

  Then write this step's output below the frontmatter.

- **If `{outputFile}` already exists**, update:
  - Leave `runScope` and `runKey` exactly as step 1 wrote them
  - Set `workflowStatus: 'in-progress'`
  - Add `'step-02-define-thresholds'` to `stepsCompleted` array (only if not already present)
  - Set `lastStep: 'step-02-define-thresholds'`
  - Set `lastSaved: '{date}'`
  - Append this step's output to the appropriate section of the document.

Load next step: `{nextStepFile}`

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.
