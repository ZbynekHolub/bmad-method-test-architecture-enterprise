---
name: 'step-04-evaluate-and-score'
description: 'Orchestrate adaptive NFR evidence domain audits (agent-team, subagent, or sequential)'
nextStepFile: '{skill-root}/steps-c/step-04e-aggregate-nfr.md'
---

# Step 4: Orchestrate Adaptive NFR Evidence Audit

## STEP GOAL

Select execution mode deterministically, then audit NFR evidence domains using agent-team, subagent, or sequential execution while preserving output contracts.

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- ✅ Resolve execution mode from config (`tea_execution_mode`, `tea_capability_probe`)
- ✅ Apply fallback rules deterministically when requested mode is unsupported
- ✅ Wait for required worker steps to complete
- ❌ Do NOT skip capability checks when probing is enabled

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Wait for subagent outputs
- 📖 Load the next step only when instructed

---

## MANDATORY SEQUENCE

### 1. Prepare Execution Context

**Generate a unique timestamp** for temp file naming, and take `run_key` from Step 1:

```javascript
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const runKey = '{run_key}'; // resolved in Step 1 and carried forward unchanged
```

Every temp file name carries `run_key` before the timestamp. `/tmp` is shared by every worktree and parallel run on the machine, and an agent without a shell invents a round timestamp, so the timestamp alone cannot keep two runs for different scopes apart.

**Prepare context:**

```javascript
const parseBooleanFlag = (value, defaultValue = true) => {
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (['false', '0', 'off', 'no'].includes(normalized)) return false;
    if (['true', '1', 'on', 'yes'].includes(normalized)) return true;
  }
  if (value === undefined || value === null) return defaultValue;
  return Boolean(value);
};

const subagentContext = {
  system_context: /* from Step 1 */,
  nfr_thresholds: /* from Step 2 */,
  declared_nfr_criteria: /* ordered, explicit assessment scope from Step 2 */,
  evidence_gathered: /* from Step 3 */,
  supplied_project_root: /* audited project root from Step 3 */,
  supplied_evidence_ledger: /* canonical ledger from Step 3 */,
  evidence_gaps: /* explicit gaps from Step 3 */,
  config: {
    execution_mode: config.tea_execution_mode || 'auto',  // "auto" | "subagent" | "agent-team" | "sequential"
    capability_probe: parseBooleanFlag(config.tea_capability_probe, true),  // supports booleans and "false"/"true" strings
  },
  run_key: runKey,
  timestamp: timestamp
};
```

---

### 2. Resolve Execution Mode with Capability Probe

```javascript
const normalizeUserExecutionMode = (mode) => {
  if (typeof mode !== 'string') return null;
  const normalized = mode.trim().toLowerCase().replace(/[-_]/g, ' ').replace(/\s+/g, ' ');

  if (normalized === 'auto') return 'auto';
  if (normalized === 'sequential') return 'sequential';
  if (normalized === 'subagent' || normalized === 'sub agent' || normalized === 'subagents' || normalized === 'sub agents') {
    return 'subagent';
  }
  if (normalized === 'agent team' || normalized === 'agent teams' || normalized === 'agentteam') {
    return 'agent-team';
  }

  return null;
};

const normalizeConfigExecutionMode = (mode) => {
  if (mode === 'subagent') return 'subagent';
  if (mode === 'auto' || mode === 'sequential' || mode === 'subagent' || mode === 'agent-team') {
    return mode;
  }
  return null;
};

// Explicit user instruction in the active run takes priority over config.
const explicitModeFromUser = normalizeUserExecutionMode(runtime.getExplicitExecutionModeHint?.() || null);

const requestedMode = explicitModeFromUser || normalizeConfigExecutionMode(subagentContext.config.execution_mode) || 'auto';
const probeEnabled = subagentContext.config.capability_probe;

const supports = {
  subagent: false,
  agentTeam: false,
};

if (probeEnabled) {
  supports.subagent = runtime.canLaunchSubagents?.() === true;
  supports.agentTeam = runtime.canLaunchAgentTeams?.() === true;
}

let resolvedMode = requestedMode;

if (requestedMode === 'auto') {
  if (supports.agentTeam) resolvedMode = 'agent-team';
  else if (supports.subagent) resolvedMode = 'subagent';
  else resolvedMode = 'sequential';
} else if (probeEnabled && requestedMode === 'agent-team' && !supports.agentTeam) {
  resolvedMode = supports.subagent ? 'subagent' : 'sequential';
} else if (probeEnabled && requestedMode === 'subagent' && !supports.subagent) {
  resolvedMode = 'sequential';
}

subagentContext.execution = {
  requestedMode,
  resolvedMode,
  probeEnabled,
  supports,
};
```

Resolution precedence:

1. Explicit user request in this run (`agent team` => `agent-team`; `subagent` => `subagent`; `sequential`; `auto`)
2. `tea_execution_mode` from config
3. Runtime capability fallback (when probing enabled)

If probing is disabled, honor the requested mode strictly. If that mode cannot be executed at runtime, fail with explicit error instead of silent fallback.

---

### 3. Dispatch 4 NFR Workers

Every worker receives the complete `supplied_evidence_ledger` and
`evidence_gaps`, plus the ordered `declared_nfr_criteria` scope. A worker emits
exactly one finding for each declared criterion in its domain, in declared
source order. It must omit every broad checklist or worker category absent from
that scope; omitted categories create no gap and cannot affect domain status.
A worker may cite only an exact `path` from the implementation-evidence ledger
and may state only an observation listed in that entry's `supports` array.
Threshold sources remain separate and never appear in a finding's `evidence`
array. A declared criterion with no matching implementation support cannot
receive PASS. The worker must emit CONCERNS, or the workflow's declared
undecidable state, and add the missing observation to the evidence gaps.

Before writing output, de-duplicate and sort every finding's evidence by
`path`, then `supports`; de-duplicate gaps while preserving declared criterion
order. These rules apply in every execution mode.

#### Subagent A: Security Evidence Audit

- File: `./step-04a-subagent-security.md`
- Output: `/tmp/tea-nfr-security-${runKey}-${timestamp}.json`
- Execution:
  - `agent-team` or `subagent`: launch non-blocking
  - `sequential`: run blocking and wait
- Status: Running... ⟳

#### Subagent B: Performance Evidence Audit

- File: `./step-04b-subagent-performance.md`
- Output: `/tmp/tea-nfr-performance-${runKey}-${timestamp}.json`
- Status: Running... ⟳

#### Subagent C: Reliability Evidence Audit

- File: `./step-04c-subagent-reliability.md`
- Output: `/tmp/tea-nfr-reliability-${runKey}-${timestamp}.json`
- Status: Running... ⟳

#### Subagent D: Maintainability Evidence Audit

- File: `./step-04d-subagent-maintainability.md`
- Output: `/tmp/tea-nfr-maintainability-${runKey}-${timestamp}.json`
- Status: Running... ⟳

In `agent-team` and `subagent` modes, runtime decides worker scheduling and concurrency.

---

### 4. Wait for Expected Worker Completion

**If `resolvedMode` is `agent-team` or `subagent`:**

```text
⏳ Waiting for 4 NFR subagents to complete...
  ├── Subagent A (Security): Running... ⟳
  ├── Subagent B (Performance): Running... ⟳
  ├── Subagent C (Reliability): Running... ⟳
  └── Subagent D (Maintainability): Running... ⟳

[... time passes ...]

✅ All 4 NFR subagents completed!
```

**If `resolvedMode` is `sequential`:**

```text
✅ Sequential mode: each worker already completed during dispatch.
```

---

### 5. Verify All Outputs Exist

```javascript
const outputs = ['security', 'performance', 'reliability', 'maintainability'].map(
  (domain) => `/tmp/tea-nfr-${domain}-${runKey}-${timestamp}.json`,
);

outputs.forEach((output) => {
  if (!fs.existsSync(output)) {
    throw new Error(`Subagent output missing: ${output}`);
  }
});
```

---

### 6. Execution Report

```text
🚀 Performance Report:
- Execution Mode: {resolvedMode}
- Total Elapsed: ~mode-dependent
- Parallel Gain: ~67% faster when mode is subagent/agent-team
```

---

### 7. Proceed to Aggregation

Load next step: `{nextStepFile}`

The aggregation step will:

- Read all 4 NFR domain outputs
- Calculate overall risk level
- Aggregate compliance status
- Identify cross-domain risks
- Generate executive summary

---

## EXIT CONDITION

Proceed when all 4 required worker steps completed and outputs exist.

---

## 🚨 SYSTEM SUCCESS METRICS

### ✅ SUCCESS:

- All required worker steps completed
- Fallback behavior respected configuration and capability probe rules

### ❌ FAILURE:

- One or more subagents failed
- Unsupported requested mode with probing disabled
