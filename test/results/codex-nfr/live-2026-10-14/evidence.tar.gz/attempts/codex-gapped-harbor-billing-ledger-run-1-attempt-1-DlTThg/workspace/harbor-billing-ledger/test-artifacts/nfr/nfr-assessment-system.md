---
runScope: 'system'
runKey: 'system'
workflowStatus: 'completed'
stepsCompleted: ["step-01-load-context", "step-02-define-thresholds", "step-03-gather-evidence", "step-04-evaluate-and-score", "step-04a-subagent-security", "step-04b-subagent-performance", "step-04c-subagent-reliability", "step-04d-subagent-maintainability", "step-04e-aggregate-nfr", "step-05-generate-report"]
lastStep: 'step-05-generate-report'
lastSaved: '2026-10-13'
workflowType: 'testarch-nfr-assess'
inputDocuments:
  - harbor-billing-ledger/_bmad/config.toml
  - harbor-billing-ledger/docs/tech-spec.md
  - bmod-tea/knowledge/tea-index.csv
  - bmod-tea/knowledge/adr-quality-readiness-checklist.md
  - bmod-tea/knowledge/ci-burn-in.md
  - bmod-tea/knowledge/test-quality.md
  - bmod-tea/knowledge/playwright-config.md
  - bmod-tea/knowledge/error-handling.md
  - harbor-billing-ledger/config/logging.json
  - harbor-billing-ledger/evidence/dependency-scan-2026-08-30.json
  - harbor-billing-ledger/evidence/load-test-2026-08-28.json
  - harbor-billing-ledger/evidence/reliability-2026-08.json
  - harbor-billing-ledger/evidence/security-review-2026-08-29.md
---
# NFR Evidence Audit: Harbor Billing Ledger

**Date:** 2026-10-13
**Scope:** Whole service; `system`
**Overall Status:** FAIL
**Overall Risk:** HIGH

This assessment audits the supplied bundle. All implementation-evidence paths below are relative to `harbor-billing-ledger/`. The audit ran each domain sequentially and collected no live evidence. The service spec declares implementation complete and awaiting release review; source code and a running deployment were absent from the supplied bundle. Assessment outcomes apply to the supplied measurements, reviews, and configuration.

## Executive Summary

**Assessment:** 9 PASS, 6 CONCERNS, 1 FAIL, 1 N/A across 17 declared criteria.

**Blockers:** 1. Reliability's Error rate requirement is breached.

**High Priority Issues:** 1 release blocker. Six CONCERNS findings require follow-up.

**Recommendation:** Resolve the Error rate failure, provide the missing evidence, agree the UNKNOWN thresholds, and rerun this audit before the release gate.

Requirements come from the tech spec. No PRD, story, or test-design plan was supplied. The test-design discovery checked `test-artifacts/test-design/` first and the legacy `test-artifacts/` root second. Five supplied implementation-evidence files form the complete citation allowlist. Embedded references to tests and source code were retained only as statements made by those supplied files.

## Performance Assessment

**Domain Status:** CONCERNS

### response-time

**Criterion ID:** `performance-response-time`

- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** k6 month-end scenario: 250 virtual users for 20 minutes; p50 96 ms, p95 214 ms, p99 388 ms; target_values_supplied false.
- **Evidence:** [evidence/load-test-2026-08-28.json](../../evidence/load-test-2026-08-28.json)
- **Supports:** k6 month-end scenario: 250 virtual users for 20 minutes; p50 96 ms, p95 214 ms, p99 388 ms; target_values_supplied false.
- **Findings:** The observed latency is measurable. Its threshold is UNKNOWN, so the finding is CONCERNS.
- **Recommendation:** Product and service owners must agree a response-time target for the close window.

### throughput

**Criterion ID:** `performance-throughput`

- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 412800 requests; throughput 344 requests/second; target_values_supplied false.
- **Evidence:** [evidence/load-test-2026-08-28.json](../../evidence/load-test-2026-08-28.json)
- **Supports:** 412800 requests; throughput 344 requests/second; target_values_supplied false.
- **Findings:** The observed throughput is measurable. Its threshold is UNKNOWN, so the finding is CONCERNS.
- **Recommendation:** Product and service owners must agree a throughput target and load profile.

### resource-usage

**Criterion ID:** `performance-resource-usage`

- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Peak CPU 58%, peak heap 61%, peak DB connections 34 of 60; target_values_supplied false.
- **Evidence:** [evidence/load-test-2026-08-28.json](../../evidence/load-test-2026-08-28.json)
- **Supports:** Peak CPU 58%, peak heap 61%, peak DB connections 34 of 60; target_values_supplied false.
- **Findings:** The observed resource usage is measurable. Its thresholds are UNKNOWN, so the finding is CONCERNS.
- **Recommendation:** Service owners must agree CPU, memory, and connection-pool ceilings.

## Security Assessment

**Domain Status:** PASS

### Authentication

**Criterion ID:** `security-authentication`

- **Status:** PASS
- **Threshold:** OAuth 2.1 on every API call; access-token lifetime <=15 minutes; refresh tokens rotate on use.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Review for ledger@4.8.2 reports OAuth 2.1 with PKCE, ES256 access tokens, 900-second lifetime, rotating refresh tokens and expired-token replay checks.
- **Evidence:** [evidence/security-review-2026-08-29.md](../../evidence/security-review-2026-08-29.md)
- **Supports:** Review for ledger@4.8.2 reports OAuth 2.1 with PKCE, ES256 access tokens, 900-second lifetime, rotating refresh tokens and expired-token replay checks.
- **Findings:** The reviewed OAuth 2.1 flow, 900-second access-token lifetime, and refresh rotation satisfy the declared requirement.

### Authorization

**Criterion ID:** `security-authorization`

- **Status:** PASS
- **Threshold:** Tenant-scoped RBAC on every statement endpoint; cross-tenant statement reads forbidden.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Review reports tenant-scoped RBAC guard on every statement route; cross-tenant tokens refused with 403 on all five routes.
- **Evidence:** [evidence/security-review-2026-08-29.md](../../evidence/security-review-2026-08-29.md)
- **Supports:** Review reports tenant-scoped RBAC guard on every statement route; cross-tenant tokens refused with 403 on all five routes.
- **Findings:** The reviewed guard placement and five cross-tenant refusals satisfy the declared requirement.

### Data protection

**Criterion ID:** `security-data-protection`

- **Status:** PASS
- **Threshold:** AES-256 at rest and TLS 1.3 in transit.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Review reports AES-256 statements and backup encryption, 90-day key rotation, TLS 1.3-only ingress and opaque settlement references.
- **Evidence:** [evidence/security-review-2026-08-29.md](../../evidence/security-review-2026-08-29.md)
- **Supports:** Review reports AES-256 statements and backup encryption, 90-day key rotation, TLS 1.3-only ingress and opaque settlement references.
- **Findings:** The reviewed encryption algorithms satisfy the declared requirement.

### Vulnerability management

**Criterion ID:** `security-vulnerability-management`

- **Status:** PASS
- **Threshold:** 0 critical and 0 high dependency findings at release; moderate and low tracked.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** npm audit for ledger@4.8.2: critical 0, high 0, moderate 3, low 7; backlog tracks moderate and low.
- **Evidence:** [evidence/dependency-scan-2026-08-30.json](../../evidence/dependency-scan-2026-08-30.json)
- **Supports:** npm audit for ledger@4.8.2: critical 0, high 0, moderate 3, low 7; backlog tracks moderate and low.
- **Findings:** Critical and high counts meet the zero-findings threshold. Moderate and low findings are explicitly allowed and tracked.

### Compliance

**Criterion ID:** `security-compliance`

- **Status:** N/A
- **Threshold:** N/A: PCI-DSS and HIPAA out of scope; no external compliance regime applies.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Compliance team confirmed no cardholder or personal health data; PCI-DSS, HIPAA and all external regimes out of scope.
- **Evidence:** [evidence/security-review-2026-08-29.md](../../evidence/security-review-2026-08-29.md)
- **Supports:** Compliance team confirmed no cardholder or personal health data; PCI-DSS, HIPAA and all external regimes out of scope.
- **Findings:** The explicitly excluded regimes are N/A. No applicable external compliance standard enters the compliance summary.

## Reliability Assessment

**Domain Status:** FAIL

### Availability

**Criterion ID:** `reliability-availability`

- **Status:** PASS
- **Threshold:** Monthly uptime >=99.5%.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** August 2026 uptime 99.71%; downtime 128 minutes.
- **Evidence:** [evidence/reliability-2026-08.json](../../evidence/reliability-2026-08.json)
- **Supports:** August 2026 uptime 99.71%; downtime 128 minutes.
- **Findings:** 99.71% meets the monthly minimum of 99.5%.

### Error rate

**Criterion ID:** `reliability-error-rate`

- **Status:** FAIL
- **Threshold:** Monthly API 5xx rate <0.5%.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** August 2026: 357348 server errors from 18420000 requests; 5xx rate 1.94%; top error statement generation 500 during close window.
- **Evidence:** [evidence/reliability-2026-08.json](../../evidence/reliability-2026-08.json)
- **Supports:** August 2026: 357348 server errors from 18420000 requests; 5xx rate 1.94%; top error statement generation 500 during close window.
- **Findings:** 1.94% breaches the strict limit of <0.5%. This finding blocks release.
- **Recommendation:** Investigate close-window statement generation 500s and worker/write saturation; demonstrate monthly 5xx rate <0.5% before release.

### MTTR

**Criterion ID:** `reliability-mttr`

- **Status:** PASS
- **Threshold:** Incident restored within 15 minutes.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** MTTR 11 minutes; incident restore times 9 and 13 minutes.
- **Evidence:** [evidence/reliability-2026-08.json](../../evidence/reliability-2026-08.json)
- **Supports:** MTTR 11 minutes; incident restore times 9 and 13 minutes.
- **Findings:** The mean of 11 minutes and both recorded incident times meet the 15-minute requirement.

### Fault tolerance

**Criterion ID:** `reliability-fault-tolerance`

- **Status:** CONCERNS
- **Threshold:** Failed ledger write retried three times with exponential backoff; regional failover drill quarterly.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Regional failover drill on 2026-08-12 passed in 38 seconds with no data loss. Retry saturation incident reported; retry count and backoff behavior unverified.
- **Evidence:** [evidence/reliability-2026-08.json](../../evidence/reliability-2026-08.json)
- **Supports:** Regional failover drill on 2026-08-12 passed in 38 seconds with no data loss. Retry saturation incident reported; retry count and backoff behavior unverified.
- **Findings:** The supplied quarterly regional drill passed. Evidence for exactly three ledger-write retries with exponential backoff remains incomplete, so the combined criterion is CONCERNS.
- **Recommendation:** Supply existing test or trace evidence showing exactly three retries with exponential backoff; maintain quarterly failover drill records.

### CI burn-in

**Criterion ID:** `reliability-ci-burn-in`

- **Status:** PASS
- **Threshold:** 100 consecutive green ledger-suite runs before release.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Ledger suite has 214 consecutive green runs; last failure 2026-06-30.
- **Evidence:** [evidence/reliability-2026-08.json](../../evidence/reliability-2026-08.json)
- **Supports:** Ledger suite has 214 consecutive green runs; last failure 2026-06-30.
- **Findings:** 214 consecutive green runs meet the minimum of 100.

## Maintainability Assessment

**Domain Status:** CONCERNS

### Test coverage

**Criterion ID:** `maintainability-test-coverage`

- **Status:** CONCERNS
- **Threshold:** Statement coverage >=80%.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** UNKNOWN; no supplied implementation evidence.
- **Evidence:** None supplied.
- **Supports:** No bound observation in the supplied-evidence ledger.
- **Findings:** Actual statement coverage is UNKNOWN. The requirements narrative provides no measured CI coverage, so >=80% remains unverified.
- **Recommendation:** Supply the existing CI statement-coverage report for the ledger build and confirm >=80%.

### Structured logging

**Criterion ID:** `maintainability-structured-logging`

- **Status:** PASS
- **Threshold:** Every ledger log line JSON with tenant_id, trace_id, event_type.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** JSON format with tenant_id, trace_id, event_type required; schema states middleware test validates every line and named test checks a sampled line.
- **Evidence:** [config/logging.json](../../config/logging.json)
- **Supports:** JSON format with tenant_id, trace_id, event_type required; schema states middleware test validates every line and named test checks a sampled line.
- **Findings:** The supplied JSON schema requires all three fields and records format assertions. This satisfies the documented-schema evidence accepted by the validation checklist; raw test results were absent.

### Error tracking

**Criterion ID:** `maintainability-error-tracking`

- **Status:** PASS
- **Threshold:** Unhandled rejections and 5xx responses reach error tracker.
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Sentry enabled with unhandled_rejection, uncaught_exception, http_5xx capture and release tagging.
- **Evidence:** [config/logging.json](../../config/logging.json)
- **Supports:** Sentry enabled with unhandled_rejection, uncaught_exception, http_5xx capture and release tagging.
- **Findings:** The supplied enabled configuration lists both required capture classes. PASS is based on integration configuration; runtime delivery was outside the supplied evidence.

### Code duplication

**Criterion ID:** `maintainability-code-duplication`

- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** UNKNOWN; no supplied implementation evidence.
- **Evidence:** None supplied.
- **Supports:** No bound observation in the supplied-evidence ledger.
- **Findings:** The duplication ceiling and measured duplication are UNKNOWN. The criterion remains CONCERNS.
- **Recommendation:** Agree a duplication ceiling and supply a measured duplication report or documented review evidence.

## Recorded-Only NFR Criteria

These requirements are preserved without automated assessment and contribute no findings, gaps, risk, or gate result.

| ID | Category | Label | Declared threshold | Threshold source | Assessment mode |
| --- | --- | --- | --- | --- | --- |
| `disaster-recovery-rto` | Disaster Recovery | RTO | 4 hours | `harbor-billing-ledger/docs/tech-spec.md` | RECORDED ONLY |
| `disaster-recovery-rpo` | Disaster Recovery | RPO | 15 minutes | `harbor-billing-ledger/docs/tech-spec.md` | RECORDED ONLY |

## Quick Wins

Three immediate audit follow-ups. Owners and effort below are proposals.

1. Attach an existing build-linked CI statement-coverage report. Suggested owner: ledger QA; estimated effort: 1 hour to locate and attach.
2. Agree response-time, throughput, resource-usage, and duplication thresholds. Suggested owners: product and ledger lead; estimated effort: 2 hours for a decision session.
3. Attach existing retry-count and backoff traces or test results. Suggested owner: ledger engineering; estimated effort: 1 hour to locate and attach.

## Recommended Actions

| Priority | Action | Suggested owner | Estimated effort | Due | Acceptance |
| --- | --- | --- | --- | --- | --- |
| HIGH | Investigate statement-generation 500s during the close window, worker exhaustion, and write saturation; remediate the verified cause | Ledger engineering and SRE | 2 days for investigation; remediation estimate follows diagnosis | Before release | Monthly 5xx rate <0.5%, supported by a new supplied export |
| MEDIUM | Provide existing retry-count and exponential-backoff evidence | Ledger engineering | 1 hour to locate evidence | Before next audit | Exactly three failed-write retries with exponential backoff supported by supplied evidence |
| MEDIUM | Supply existing statement-coverage report for the ledger build | Ledger QA | 1 hour to locate evidence | Before next audit | Measured statement coverage >=80% |
| MEDIUM | Agree a response-time target for month-end workload | Product and ledger lead | 1 hour | Before next audit | Explicit target and matching supplied latency measurement |
| MEDIUM | Agree throughput target and workload profile | Product and ledger lead | 1 hour | Before next audit | Explicit target and matching supplied throughput measurement |
| MEDIUM | Agree CPU, memory, and database-pool ceilings | Ledger lead and SRE | 1 hour | Before next audit | Explicit resource ceilings and matching supplied measurements |
| MEDIUM | Agree duplication ceiling and supply measured report or review evidence | Ledger lead | 2 hours for agreement and evidence review | Before next audit | Explicit threshold and supported actual duplication |

## Monitoring Hooks

Proposed follow-ups; this audit changed no monitoring configuration.

- Reliability: SRE should monitor monthly 5xx rate against the declared <0.5% threshold and route a breach alert before release.
- Performance: after target agreement, SRE should compare month-end latency, throughput, and resource usage with those targets.
- Security: release engineering should retain build-linked scans and block releases with critical or high dependency findings.
- Maintainability: ledger QA should retain build-linked statement-coverage results and verify error-tracker capture delivery during the next validation cycle.

## Fail-Fast Mechanisms

Proposed gates: require 5xx evidence below 0.5%, statement coverage >=80%, zero critical/high dependency findings, and 100 consecutive green ledger-suite runs. Assign release engineering as gate owner; review before release. Review retry exhaustion handling against the declared retry/backoff requirement. Performance limits and duplication gates require agreed thresholds before configuration. No standalone circuit-breaker or rate-limiting requirement was declared.

## Evidence Gaps

Five structured gaps in declared source order. Each unsupported criterion appears once. Fault tolerance has partial support and is followed up in its finding and action; it creates no additional unsupported-criterion gap.

- **performance-response-time:** response-time: declared threshold is UNKNOWN
- **performance-throughput:** throughput: declared threshold is UNKNOWN
- **performance-resource-usage:** resource-usage: declared threshold is UNKNOWN
- **maintainability-test-coverage:** Test coverage: no supplied implementation evidence
- **maintainability-code-duplication:** Code duplication: no supplied implementation evidence

Suggested collection plan:

| Criterion ID | Suggested owner | Deadline | Suggested evidence or decision | Impact |
| --- | --- | --- | --- | --- |
| performance-response-time | Product and ledger lead | Before next audit | Agreed latency target for supplied month-end profile | Response-time judgment remains CONCERNS |
| performance-throughput | Product and ledger lead | Before next audit | Agreed throughput target and workload profile | Throughput judgment remains CONCERNS |
| performance-resource-usage | Ledger lead and SRE | Before next audit | Agreed CPU, heap, and database-pool ceilings | Resource-usage judgment remains CONCERNS |
| maintainability-test-coverage | Ledger QA | Before next audit | Existing build-linked CI statement-coverage report | >=80% cannot be verified |
| maintainability-code-duplication | Ledger lead | Before next audit | Agreed ceiling plus measured duplication or documented review evidence | Threshold and actual remain UNKNOWN |

## Findings Summary

| Audited domain | PASS | CONCERNS | FAIL | N/A | Domain status | Risk |
| --- | --- | --- | --- | --- | --- | --- |
| Performance | 0 | 3 | 0 | 0 | CONCERNS | MEDIUM |
| Security | 4 | 0 | 0 | 1 | PASS | LOW |
| Reliability | 3 | 1 | 1 | 0 | FAIL | HIGH |
| Maintainability | 2 | 2 | 0 | 0 | CONCERNS | MEDIUM |
| Total | 9 | 6 | 1 | 1 | FAIL | HIGH |

ADR Quality Readiness Checklist scoring: N/A. Its eight categories elicited declared requirements; the checklist created no additional criteria or statuses. The gate's ADR `categories` mapping is empty because this audit rolls up the four declared audit domains. Custom NFR categories: N/A. Compliance summary: no applicable external regime. Cross-domain risks: none supported by an identical shared ledger observation.

## Related Artifacts

- Threshold source: `harbor-billing-ledger/docs/tech-spec.md`.
- Run configuration: `harbor-billing-ledger/_bmad/config.toml`.
- PRD, story, and test-design plan: absent from the supplied bundle.
- Implementation-evidence inventory: five files, cited under their bound criteria above. No generated report, template, temporary worker output, or requirements document entered the evidence ledger.

## Recommendations Summary

**Release Blocker:** Reliability Error rate FAIL.

**High Priority:** Resolve the monthly 5xx threshold breach before release.

**Medium Priority:** Resolve six CONCERNS findings and five structured evidence/threshold gaps.

**Next Steps:** Resolve failed requirements and follow-ups, supply the updated evidence bundle, rerun `bmad-testarch-nfr`, then use `bmad-testarch-trace` Phase 2 for the release gate decision.

## Validation Summary

The complete report was checked against `skill/checklist.md` and Step 5's publication contract. Canonical evidence paths and supported statements were checked against all five ledger entries. Every criterion has one ordered subsection, every bound observation is cited, UNKNOWN thresholds remain CONCERNS, and recorded-only criteria appear once in their table. No rejected citation appears. The checklist's generic discovery hints created no added finding or gap. Missing coverage and duplication evidence is recorded above. Browser collection was disabled; no session was opened. Deployment access was unavailable in the bundle, so this remains a supplied-evidence audit.

The closed Step 1 knowledge selection loaded ADR readiness, CI burn-in, test quality, Playwright config, and error-handling fragments. The checklist's mention of nfr-criteria did not expand that closed selection. Protected docs, evidence, and config contents were verified unchanged.

## Sign-Off

**Overall Status:** FAIL
**Gate Status:** FAIL
**Critical Issues:** 0
**High Priority Issues:** 1
**Medium Priority Issues:** 6
**Concerns:** 6
**Evidence Gaps:** 5
**Waivers:** None supplied or granted.

Generated 2026-10-13 using testarch-nfr v5.0. Completion: the evidence audit is complete; the release gate is blocked by the Reliability failure.

## Gate YAML Snippet

```yaml
nfr_assessment:
  date: '2026-10-13'
  run_scope: 'system'
  run_key: 'system'
  story_id: null
  feature_name: 'Harbor Billing Ledger'
  adr_checklist_score: 'N/A'
  categories: {}
  audited_domains:
    security: 'PASS'
    performance: 'CONCERNS'
    reliability: 'FAIL'
    maintainability: 'CONCERNS'
  overall_status: 'FAIL'
  critical_issues: 0
  high_priority_issues: 1
  medium_priority_issues: 6
  concerns: 6
  blockers: true
  quick_wins: 3
  evidence_gaps: 5
  recommendations:
    - 'Resolve the monthly API 5xx breach and supply evidence below 0.5%.'
    - 'Agree UNKNOWN performance and duplication thresholds and supply coverage and duplication evidence.'
    - 'Complete retry/backoff evidence, rerun the NFR audit, then run trace Phase 2.'
```
