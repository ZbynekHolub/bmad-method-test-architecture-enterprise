---
runScope: 'system'
runKey: 'system'
workflowStatus: 'completed'
stepsCompleted: ['step-01-load-context', 'step-02-define-thresholds', 'step-03-gather-evidence', 'step-04-evaluate-and-score', 'step-04a-subagent-security', 'step-04b-subagent-performance', 'step-04c-subagent-reliability', 'step-04d-subagent-maintainability', 'step-04e-aggregate-nfr', 'step-05-generate-report']
lastStep: 'step-05-generate-report'
lastSaved: '2026-10-14T03:22:16.637547+00:00'
workflowType: 'testarch-nfr-assess'
inputDocuments:
  - 'harbor-billing-ledger/_bmad/config.toml'
  - 'harbor-billing-ledger/docs/tech-spec.md'
  - 'bmod-tea/knowledge/adr-quality-readiness-checklist.md'
  - 'bmod-tea/knowledge/ci-burn-in.md'
  - 'bmod-tea/knowledge/test-quality.md'
  - 'bmod-tea/knowledge/playwright-config.md'
  - 'bmod-tea/knowledge/error-handling.md'
  - 'harbor-billing-ledger/config/logging.json'
  - 'harbor-billing-ledger/evidence/dependency-scan-2026-08-30.json'
  - 'harbor-billing-ledger/evidence/load-test-2026-08-28.json'
  - 'harbor-billing-ledger/evidence/reliability-2026-08.json'
  - 'harbor-billing-ledger/evidence/security-review-2026-08-29.md'
---

# NFR Evidence Audit: Harbor Billing Ledger

**Date:** 2026-10-13
**Scope:** Whole service; `runScope: system`, `runKey: system`.
**Overall Status:** FAIL
**Overall Risk:** HIGH

This audit uses the supplied implementation evidence. No tests, CI jobs, live browser sessions, or new service evidence were generated.

## Executive Summary

**Assessment:** 9 PASS, 6 CONCERNS, 1 FAIL, 1 N/A across 17 declared criteria.

**Blockers:** 1. Monthly 5xx rate is 1.94%; the requirement is below 0.5%.

**High Priority Issues:** 1. Reduce the close-window error rate and provide a comparable monthly measurement.

**Recommendation:** Hold release pending resolution of the error-rate FAIL. Resolve the remaining target and evidence concerns, then rerun this audit before the release gate decision.

Execution was sequential across four domains, with capability probing disabled. The supplied requirements are in `harbor-billing-ledger/docs/tech-spec.md`. No PRD, story, or test-design plan was supplied. No custom categories were configured.

## Performance Assessment

**Domain Status:** CONCERNS
**Domain Risk:** MEDIUM

### response-time

- **Criterion ID:** `performance-response-time`; source order 6.
- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** p50 96 ms; p95 214 ms; p99 388 ms
- **Evidence:** `harbor-billing-ledger/evidence/load-test-2026-08-28.json`
- **Supports:** k6 month-end run: 250 virtual users for 20 minutes; p50 96 ms, p95 214 ms, p99 388 ms; target_values_supplied false
- **Findings:** Acceptance cannot be determined until the declared threshold is defined.
- **Recommendation:** Product and service owners: agree response-time targets for the month-end scenario

### throughput

- **Criterion ID:** `performance-throughput`; source order 7.
- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 344 requests/second; 412800 requests over 20 minutes
- **Evidence:** `harbor-billing-ledger/evidence/load-test-2026-08-28.json`
- **Supports:** 412800 requests in 20 minutes; throughput 344 requests/second; no targets supplied
- **Findings:** Acceptance cannot be determined until the declared threshold is defined.
- **Recommendation:** Product and service owners: agree a throughput target for the month-end scenario

### resource-usage

- **Criterion ID:** `performance-resource-usage`; source order 8.
- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Peak CPU 58%; peak heap 61%; DB pool peak 34/60
- **Evidence:** `harbor-billing-ledger/evidence/load-test-2026-08-28.json`
- **Supports:** Peak CPU 58%, peak heap 61%, DB connection pool peak 34 of 60; no targets supplied
- **Findings:** Acceptance cannot be determined until the declared threshold is defined.
- **Recommendation:** Service and platform owners: agree CPU, heap and connection-pool limits

## Security Assessment

**Domain Status:** PASS
**Domain Risk:** LOW

### Authentication

- **Criterion ID:** `security-authentication`; source order 1.
- **Status:** PASS
- **Threshold:** OAuth 2.1 on every API call; access token lifetime <=15 minutes; refresh tokens rotate on use
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** OAuth 2.1 with PKCE; 900-second access tokens; refresh tokens rotate and previous tokens are revoked
- **Evidence:** `harbor-billing-ledger/evidence/security-review-2026-08-29.md`
- **Supports:** OAuth 2.1 authorization code with PKCE; access tokens 900 seconds; refresh rotation and previous-token revocation; review reports expired-token checks on every statement route
- **Findings:** The supplied observation meets the declared threshold.

### Authorization

- **Criterion ID:** `security-authorization`; source order 2.
- **Status:** PASS
- **Threshold:** Tenant-scoped RBAC on every statement endpoint; cross-tenant reads prohibited
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Tenant guard on every statement route; cross-tenant reads refused 5/5 with 403 and audit records
- **Evidence:** `harbor-billing-ledger/evidence/security-review-2026-08-29.md`
- **Supports:** Review reports tenant RBAC guard before every statement route; all five cross-tenant tests returned 403 with audit records
- **Findings:** The supplied observation meets the declared threshold.

### Data protection

- **Criterion ID:** `security-data-protection`; source order 3.
- **Status:** PASS
- **Threshold:** AES-256 at rest and TLS 1.3 in transit
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** AES-256 for statements and backups; TLS 1.3 only
- **Evidence:** `harbor-billing-ledger/evidence/security-review-2026-08-29.md`
- **Supports:** Review reports statements and backups encrypted with AES-256; TLS 1.3 only; no downgrade path; opaque settlement references
- **Findings:** The supplied observation meets the declared threshold.

### Vulnerability management

- **Criterion ID:** `security-vulnerability-management`; source order 4.
- **Status:** PASS
- **Threshold:** 0 critical and 0 high dependency findings; moderate and low tracked
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 0 critical, 0 high, 3 moderate, 7 low dependency findings
- **Evidence:** `harbor-billing-ledger/evidence/dependency-scan-2026-08-30.json`
- **Supports:** npm audit for ledger@4.8.2: 0 critical, 0 high, 3 moderate, 7 low; moderate and low tracked in dependency backlog
- **Findings:** The supplied observation meets the declared threshold.

### Compliance

- **Criterion ID:** `security-compliance`; source order 5.
- **Status:** N/A
- **Threshold:** No external compliance regime applies; PCI-DSS and HIPAA out of scope
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Review confirms no cardholder or personal health data and no applicable external regime
- **Evidence:** `harbor-billing-ledger/evidence/security-review-2026-08-29.md`
- **Supports:** Compliance review confirms no cardholder or personal health data; PCI-DSS, HIPAA and other external regimes do not apply
- **Findings:** PCI-DSS and HIPAA are explicitly out of scope; no external regime applies.

## Reliability Assessment

**Domain Status:** FAIL
**Domain Risk:** HIGH

### Availability

- **Criterion ID:** `reliability-availability`; source order 9.
- **Status:** PASS
- **Threshold:** Monthly uptime >=99.5%
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 99.71% monthly uptime; 128 minutes downtime
- **Evidence:** `harbor-billing-ledger/evidence/reliability-2026-08.json`
- **Supports:** August 2026 uptime 99.71%; 128 downtime minutes
- **Findings:** The supplied observation meets the declared threshold.

### Error rate

- **Criterion ID:** `reliability-error-rate`; source order 10.
- **Status:** FAIL
- **Threshold:** Monthly 5xx rate <0.5% of ledger API requests
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 1.94% monthly 5xx rate; 357348/18420000 requests
- **Evidence:** `harbor-billing-ledger/evidence/reliability-2026-08.json`
- **Supports:** 357348 server errors among 18420000 requests; 5xx rate 1.94%; top error is statement generation during close
- **Findings:** The measured monthly rate breaches the declared limit and blocks release.
- **Recommendation:** HIGH, before release: service owner must reduce monthly 5xx rate below 0.5% and supply a comparable monthly export

### MTTR

- **Criterion ID:** `reliability-mttr`; source order 11.
- **Status:** PASS
- **Threshold:** Incident restored within 15 minutes
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 11-minute MTTR; individual incidents 9 and 13 minutes
- **Evidence:** `harbor-billing-ledger/evidence/reliability-2026-08.json`
- **Supports:** Mean recovery 11 minutes; both listed incidents restored in 9 and 13 minutes
- **Findings:** The supplied observation meets the declared threshold.

### Fault tolerance

- **Criterion ID:** `reliability-fault-tolerance`; source order 12.
- **Status:** CONCERNS
- **Threshold:** Failed ledger writes retried three times with exponential backoff; regional failover drill once per quarter
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Regional failover passed on 2026-08-12: 38 seconds, no data loss; retry count and exponential backoff unmeasured
- **Evidence:** `harbor-billing-ledger/evidence/reliability-2026-08.json`
- **Supports:** Regional failover drill passed on 2026-08-12 in 38 seconds with no data loss; incident mentions write-retry saturation, without retry count or backoff measurements
- **Findings:** The failover drill supports the regional requirement. The retry count and exponential backoff remain unverified.
- **Recommendation:** Service owner: supply existing failed-write retry traces proving three retries with exponential backoff

### CI burn-in

- **Criterion ID:** `reliability-ci-burn-in`; source order 13.
- **Status:** PASS
- **Threshold:** 100 consecutive green ledger-suite runs before release
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** 214 consecutive green ledger-suite runs
- **Evidence:** `harbor-billing-ledger/evidence/reliability-2026-08.json`
- **Supports:** Ledger suite has 214 consecutive green runs; last failure 2026-06-30
- **Findings:** The supplied observation meets the declared threshold.

## Maintainability Assessment

**Domain Status:** CONCERNS
**Domain Risk:** MEDIUM

### Test coverage

- **Criterion ID:** `maintainability-test-coverage`; source order 15.
- **Status:** CONCERNS
- **Threshold:** Statement coverage >=80%
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** UNKNOWN; no supplied CI coverage report
- **Evidence:** None supplied under `harbor-billing-ledger/` for this criterion.
- **Supports:** No supplied implementation observation.
- **Findings:** The absence of a supplied report leaves the achieved value UNKNOWN.
- **Recommendation:** Service owner: supply the existing ledger statement-coverage report demonstrating >=80%

### Structured logging

- **Criterion ID:** `maintainability-structured-logging`; source order 16.
- **Status:** PASS
- **Threshold:** Every log line JSON with tenant_id, trace_id, event_type
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** JSON logging configured; tenant_id, trace_id, event_type required; middleware-validation and sampled-field assertions reported
- **Evidence:** `harbor-billing-ledger/config/logging.json`
- **Supports:** JSON schema requires tenant_id, trace_id, event_type; file states middleware tests validate every line and log-format test asserts required fields on a sample
- **Findings:** The supplied observation meets the declared threshold.

### Error tracking

- **Criterion ID:** `maintainability-error-tracking`; source order 17.
- **Status:** PASS
- **Threshold:** Unhandled rejections and 5xx responses reach the error tracker
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** Sentry enabled; unhandled_rejection and http_5xx captured; release tagging enabled
- **Evidence:** `harbor-billing-ledger/config/logging.json`
- **Supports:** Sentry enabled; captures unhandled_rejection, uncaught_exception and http_5xx; release tagging enabled
- **Findings:** The supplied observation meets the declared threshold.

### Code duplication

- **Criterion ID:** `maintainability-code-duplication`; source order 18.
- **Status:** CONCERNS
- **Threshold:** UNKNOWN
- **Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`
- **Actual:** UNKNOWN; no supplied duplication measurement
- **Evidence:** None supplied under `harbor-billing-ledger/` for this criterion.
- **Supports:** No supplied implementation observation.
- **Findings:** Acceptance cannot be determined until the declared threshold is defined.
- **Recommendation:** Service owner: agree a duplication ceiling and supply the existing review or measurement evidence

## Recorded-Only NFR Criteria

These criteria were preserved without automated assessment.

| ID | Category | Label | Declared threshold | Threshold source | Assessment mode |
| --- | --- | --- | --- | --- | --- |
| disaster-recovery-disaster-recovery | Disaster Recovery | Disaster recovery | RTO 4 hours; RPO 15 minutes | `harbor-billing-ledger/docs/tech-spec.md` | RECORDED ONLY |

## Quick Wins

2 quick wins are proposed. Effort estimates are planning estimates; owners are suggested roles.

1. **Attach the existing coverage report.** Maintainability; MEDIUM; 1 hour; service owner. Provide build-tagged statement coverage with its denominator and service scope. Acceptance: coverage at or above 80%.
2. **Agree the missing ceilings and targets.** Performance and Maintainability; MEDIUM; 2 hours; product and service owners. Define response-time, throughput, resource-usage, and duplication thresholds, with the month-end load scenario recorded.

## Recommended Actions

| Priority | Criterion | Action and validation | Suggested owner | Estimated effort | Deadline |
| --- | --- | --- | --- | --- | --- |
| HIGH | reliability-error-rate | Investigate the reported close-window statement-generation 500s and supplied incidents involving worker-pool exhaustion and write-retry saturation. Resolve the failure, then supply a comparable monthly export demonstrating 5xx below 0.5%. | Service owner with platform operations | 1 day for initial investigation; repair estimate after diagnosis | Before release |
| MEDIUM | performance-response-time | Agree latency acceptance targets for the declared month-end scenario; judge the existing result against those approved targets. | Product and service owners | 1 hour | Next milestone |
| MEDIUM | performance-throughput | Agree the minimum throughput and tenant/load profile; document the accepted target. | Product and service owners | 1 hour | Next milestone |
| MEDIUM | performance-resource-usage | Define CPU, heap and connection-pool ceilings for the close window. | Service and platform owners | 1 hour | Next milestone |
| MEDIUM | reliability-fault-tolerance | Supply existing retry traces or test results demonstrating three failed-write retries and exponential backoff. | Service owner | 2 hours for evidence retrieval | Next milestone |
| MEDIUM | maintainability-test-coverage | Supply the existing scoped CI report and verify statement coverage at or above 80%. | Service owner | 1 hour | Next milestone |
| MEDIUM | maintainability-code-duplication | Agree the duplication ceiling and provide existing manual-review or measurement evidence. | Service owner | 2 hours | Next milestone |

**Long-term backlog:** N/A. This audit identifies no additional declared criteria requiring backlog actions.

## Monitoring Hooks

Recommendations describe follow-up work. They do not claim that a monitoring hook already exists.

| Hook | Suggested owner | Deadline | Alert or review condition |
| --- | --- | --- | --- |
| Monthly 5xx ratio with close-window route breakdown | Platform operations | Before release | Measured monthly 5xx rate at or above 0.5% breaches the declared requirement |
| Month-end latency, throughput, CPU, heap and connection-pool dashboard review | Service owner | Next milestone | Use approved targets once defined; alert thresholds remain UNKNOWN |
| Existing dependency-scan backlog review | Service and security owners | Each release | Any critical or high finding blocks release; maintain moderate and low tracking |
| Recovery-time and burn-in evidence review | Service owner | Each release | Incident restoration exceeds 15 minutes, or consecutive green ledger-suite runs are below 100 |

## Fail-Fast Mechanisms

| Proposed gate | Suggested owner | Estimated effort | Validation |
| --- | --- | --- | --- |
| Reject a release with monthly 5xx rate at or above 0.5% | Service owner | 2 hours to specify gate | Attach comparable scoped monthly metrics |
| Require retry-count and exponential-backoff evidence | Service owner | 2 hours for evidence review | Three failed-write retries and backoff verified |
| Preserve critical/high dependency and statement-coverage checks | Service owner | 2 hours to specify checks | 0 critical, 0 high; statement coverage at or above 80% |

**Circuit-breaker requirement:** N/A; absent from the declared scope.
**Rate-limit requirement:** N/A; absent from the declared scope.
**Duplication gate threshold:** UNKNOWN; agree the ceiling before defining a gate.

## Evidence Gaps

5 structured evidence or threshold gaps:

- **performance-response-time:** response-time: declared threshold is UNKNOWN
- **performance-throughput:** throughput: declared threshold is UNKNOWN
- **performance-resource-usage:** resource-usage: declared threshold is UNKNOWN
- **maintainability-test-coverage:** Test coverage: no supplied implementation evidence
- **maintainability-code-duplication:** Code duplication: no supplied implementation evidence

| Criterion ID | Suggested owner | Deadline | Suggested evidence or decision | Impact |
| --- | --- | --- | --- | --- |
| performance-response-time | Product and service owners | Next milestone | Approved acceptance target for the supplied month-end scenario | Criterion remains CONCERNS |
| performance-throughput | Product and service owners | Next milestone | Approved acceptance target for the supplied month-end scenario | Criterion remains CONCERNS |
| performance-resource-usage | Product and service owners | Next milestone | Approved acceptance target for the supplied month-end scenario | Criterion remains CONCERNS |
| maintainability-test-coverage | Service owner | Next milestone | Build-tagged ledger statement-coverage report with service scope | Criterion remains CONCERNS |
| maintainability-code-duplication | Service owner | Next milestone | Approved duplication ceiling and existing review or measurement report | Criterion remains CONCERNS |

Code duplication also has an UNKNOWN threshold. Fault tolerance has partial support: the supplied failover result leaves retry-count and backoff checks unresolved. This limitation remains within its finding.

## Findings Summary

| Domain | Declared criteria | PASS | CONCERNS | FAIL | N/A | Overall status |
| --- | --- | --- | --- | --- | --- | --- |
| Performance | 3 | 0 | 3 | 0 | 0 | CONCERNS |
| Security | 5 | 4 | 0 | 0 | 1 | PASS |
| Reliability | 5 | 3 | 1 | 1 | 0 | FAIL |
| Maintainability | 4 | 2 | 2 | 0 | 0 | CONCERNS |
| Total | 17 | 9 | 6 | 1 | 1 | FAIL |

The ADR checklist supplied elicitation context. Its 29 criteria were not individually declared or audited, so its numerical score is N/A. Gate `categories` fields with N/A are schema placeholders for unassessed checklist categories. Assessed category summaries cover only declared findings mapped to that category. The four `audited_domains` values carry the domain decisions.

**Cross-domain risks:** 0. The audited findings share no exact evidence item across domains.

**Compliance summary:** No applicable external standard. The declared compliance finding is N/A.

## Related Artifacts

**Threshold Source:** `harbor-billing-ledger/docs/tech-spec.md`.

**Configuration:** `harbor-billing-ledger/_bmad/config.toml`.

**Story, PRD, test design:** N/A; none supplied.

**Implementation evidence ledger:** Five supplied files, rendered beside their supported findings. Paths named inside reviews were not separately supplied and were not used as independent evidence.

**Coverage and duplication artifacts:** Missing.

## Recommendations Summary

**Release Blocker:** Resolve the error-rate FAIL and supply comparable monthly evidence.

**High Priority:** Investigate close-window statement-generation 500s using the supplied reliability export.

**Medium Priority:** Define performance and duplication thresholds; supply coverage and retry behavior evidence.

**Next Steps:** Rerun `bmad-testarch-nfr` after remediation and evidence updates, then run `bmad-testarch-trace` Phase 2 for the release gate decision.

## Sign-Off

**Overall Status:** FAIL.
**Overall Risk:** HIGH.
**Critical Issues:** 0.
**High Priority Issues:** 1.
**Medium Priority Issues:** 6.
**Concerns:** 6.
**Evidence Gaps:** 5.
**Gate Status:** FAIL; release blocked.

Validation covers declared criterion order, audited evidence observations, threshold separation, exact gap scope, domain/gate agreement, and recorded-only separation. Browser sessions: N/A; browser automation disabled. No rejected citations were published. The supplied docs, evidence, and config files remain unchanged.

**Generated:** 2026-10-13.
**Workflow:** testarch-nfr v5.0.

## Gate YAML Snippet

```yaml
nfr_assessment:
  date: '2026-10-13'
  story_id: null
  feature_name: 'Harbor Billing Ledger'
  run_scope: 'system'
  run_key: 'system'
  adr_checklist_score: 'N/A'
  categories:
    testability_automation: 'N/A'
    test_data_strategy: 'N/A'
    scalability_availability: 'FAIL'
    disaster_recovery: 'N/A'
    security: 'PASS'
    monitorability: 'PASS'
    qos_qoe: 'CONCERNS'
    deployability: 'N/A'
  audited_domains:
    security: 'PASS'
    performance: 'CONCERNS'
    reliability: 'FAIL'
    maintainability: 'CONCERNS'
  overall_status: 'FAIL'
  overall_risk: 'HIGH'
  critical_issues: 0
  high_priority_issues: 1
  medium_priority_issues: 6
  concerns: 6
  blockers: true
  quick_wins: 2
  evidence_gaps: 5
  recommendations:
    - 'Resolve monthly 5xx breach and supply comparable evidence below 0.5%.'
    - 'Define performance and duplication acceptance thresholds.'
    - 'Supply scoped coverage and retry behavior evidence; rerun the audit before trace Phase 2.'
```
